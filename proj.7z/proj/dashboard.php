<?php

session_start();

?>

<html>
<head>
<title>CordovaApp</title>
  
  
    <meta charset="utf-8">
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style1.css" />
	
    
</head>


<body>


	<?php
	
	session_start();
	if(isset($_SESSION['username'])) {
	#echo 'Welcome, '.$_SESSION['username'];
		$oguser=$_SESSION['username'];
	}else {
		echo 'Please log in';
	}
	?>
	<ul class="cb-slideshow">
            <li><span>Image 01</span></li> 
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
			<li><span>Image 06</span></li>
</ul>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
	  Dashboard</a>
    </div>
	<ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
	 </ul>
	</div>
	</nav>
	<div class="container" style="position: relative;">
  <div class="panel-group">
    <div class="panel panel-primary">
      <div class="panel-heading">
	
	  Welcome <?php echo $oguser ?> </div>
    </div>
	</div>
	</div>
	<form id="myForm" action="connection.php" method="post">
	<div style="margin-left:140px;position: relative;">
	<label for="blood" style="font-size:20px;">Are you a :</label><br>
    <input type="radio"  name="blood" value="donor" > 
	<label style="font-size:15px;"> Donor </label> <br>
	<input type="radio"  name="blood" value="receiver" > 
	<label style="font-size:15px;"> Receiver </label> <br>
	</div>
	<div class="form-group" style="margin-left:140px;position: relative;">
    <button type="sub" class="btn btn-success">Submit</button>
    </div>
	</form>
</body>
</html>