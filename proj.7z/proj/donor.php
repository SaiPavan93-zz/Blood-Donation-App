<?php
	session_start();
		
    $con = mysqli_connect("localhost", "root", "12345");
    if(!$con)
    {
        echo "Not connected To Server";
    }
    if(!mysqli_select_db($con,"app"))
    {
        echo "Database not selected";
    }

       $blood1 = $_POST["blood1"];
	   //echo ("1".$blood1);
	   $blood2 = $_POST["blood2"];
	   //echo ("2".$blood2);
	  
	   $blood3 = $_POST["blood3"];
	    if($blood2=="no")
	   {
		   $blood3= "no";
	   }
	  // echo ("3".$blood3);
	   $blood4 = $_POST["blood4"];
	   //echo ("4".$blood4);
	   $blood5 = $_POST["blood5"];
	   //echo ("5".$blood5);
	   $blood6 = $_POST["blood6"];
	   //echo ("6".$blood6);
	   $blood7 = $_POST["blood7"];
	   //echo ("7".$blood7);
	   $blood8 = $_POST["blood8"];
	   //echo ("8".$blood8);
	   $blood9 = $_POST["blood9"];
	   //echo ("9".$blood9);
	   $blood10 = $_POST["blood10"];
	   //echo ("10".$blood10);
	   $blood11 = $_POST["blood11"];
	   //echo ("11".$blood11);
	   $blood12 = $_POST["blood12"];
	   //echo ("12".$blood12);
	   $blood13 = $_POST["blood13"];
	   //echo ("13".$blood13);
	   $blood14 = $_POST["blood14"];
	   //echo ("14".$blood14);
	   $blood15= $_POST["blood15"];
	   echo("15".$blood15);
	  $statement = "INSERT INTO blooddonors (age, donatedblood, donatedin8weeks, piercingtattoo, temperature99, bleeingcondition,alcoholic,HIVAIDS,needlesdrugs,gonorrhea,prison,europe,malaria,bloodgroup,username) VALUES ('$blood1',' $blood2','$blood3','$blood4', '$blood5', '$blood6',' $blood7','$blood8',' $blood9',' $blood10',' $blood11',' $blood12',' $blood13',' $blood14','$blood15')";
	   if(!mysqli_query($con,$statement))
    {
        echo "Not Inserted";
    }
    else
    {
		
       header("Location:http://192.168.1.76:3000/googlemaps.html");
    }
	 ?>