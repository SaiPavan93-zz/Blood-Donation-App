$("#sub").click(function() {

$.post($("#myForm").attr("action"),
$("#myForm :input").serializeArray(), function(info){$("#result").html(info);});
clearInput();


	});

 $("#myForm").submit( function() {
	return true;
}); 

function clearInput()
{
	$("#myForm :input").each( function() {
	   $(this).val('');
	   /* window.location.href = "login.html"; */
	   /* window.location.replace("login.html"); */
	});
}
