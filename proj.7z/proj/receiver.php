<?php
	session_start();
		
    $con = mysqli_connect("localhost", "root", "12345");
    if(!$con)
    {
        echo "Not connected To Server";
    }
    if(!mysqli_select_db($con,"app"))
    {
        echo "Database not selected";
    }
	$blood1=$_POST["blood1"];
	//echo ("1".$blood1);
	$blood2=$_POST["blood2"];
	//echo ("2".$blood2);
	$email=$_POST["email"];
	//echo ("3".$email);
	$contact=$_POST["contact"];
	//echo ("4".$contact);
	$blood4=$_POST["blood4"];
	//echo ("5".$blood4);
	$blood5= $_POST["blood5"];
	//echo("6".$blood5);
	
	$statement= "INSERT INTO bloodreceivers(username,email,contact,bloodunits,requirement,bloodgroup) VALUES ('$blood5','$email','$contact','$blood1','$blood2','$blood4')";
	   if(!mysqli_query($con,$statement))
    {
        echo "Not Inserted";
    }
    else
    {
		
        header("Location:http://192.168.1.76:3000/googlemaps.html");
    }
	?>