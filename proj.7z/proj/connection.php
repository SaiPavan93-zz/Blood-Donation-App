<?php
	session_start();
	$blood = $_POST['blood'];
	$username=$_SESSION['username'];
	if(isset($_POST['blood']))
	{
		if ($blood == "donor")
		{
			header("Location:http://192.168.1.76:3000/donor.html?username=".$username);
		}
		elseif ($blood == "receiver")
		{
			header("Location:http://192.168.1.76:3000/receiver.html?username=".$username);
		}
	}
	
	
?>